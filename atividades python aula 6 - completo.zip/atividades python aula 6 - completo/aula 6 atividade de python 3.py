# Faça um programa em Python que leia um valor n, inteiro e positivo, calcule e mostrea seguinte soma {...}

a = int(input("Digite um valor positivo e inteiro: "))

soma = 0

for i in range(a):
    soma = soma + (1 / (1 + 1))

print(f"Ao todo, a soma será: {soma:.2f}")
