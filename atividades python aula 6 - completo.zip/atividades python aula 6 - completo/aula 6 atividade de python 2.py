# números de 1 a 50 de 1 em 1 e de 52 a100 de 2 em 2

print("Numeros de 1 a 50 de 1 em 1")
for i in range(1, 51, 1):
    print(i, end=" ")

print("                         ")

print("Numeros de 52 a 100 de 2 em 2")
for i in range(52, 101, 2):
    print(i, end=" ")
