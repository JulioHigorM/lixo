
# numeros pares entre 0 e 100

print("Numeros pares de 0 a 100")

for i in range(0, 101, 2):
    print(i, end=" ")
