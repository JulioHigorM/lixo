
fem = 0
masc = 0
alfem = 0
almasc = 0
quantidade = int(input("Digite a quantidade de pessoas que deseja analisar: "))

for i in range(quantidade):
    sexo = input(f"Digite m para masculino e f para feminino: ")
    altura = float(input(f"Digite sua altura: "))

if sexo == "f" or "F":
    alfem += altura
    fem += 1

elif sexo == "m" or "M":
    almasc += altura
    masc += 1

else:
    print("sexo invalido, por favor coloque m ou f")

almasc = almasc / masc if masc > 0 else 0
alfem = alfem / fem if fem > 0 else 0


print(f"A altura media dos homens é: {almasc}")
print(f"A altura media das mulheres é: {alfem}")
