
positivo = 0
negativo = 0
menor = None
quantidade = int(input("Digite a quantidade de valores que deseja analisar: "))

for i in range(quantidade):
    valor = float(input(f"Digite o {i+1} valor: "))

    if valor > 0:
        positivo += 1

    elif valor < 0:
        negativo += 1

    if menor is None or valor < menor:
        menor = valor

print(f"Número de valores positivos: {positivo}")
print(f"Número de valores negativos: {negativo}")
print(f"menor valor inserido: {menor}")
