# aula 1 - atividades python 5 - input 4

a = str(input("Qual seu esporte preferido?: "))

print(('Seu esport epreferido é:'), (a))
