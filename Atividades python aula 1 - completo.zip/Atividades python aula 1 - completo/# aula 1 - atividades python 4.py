# aula 1 - atividades python 4 - input 3

a = str(input('Digite seu sobrenome: '))

print(("Família"), (a))
