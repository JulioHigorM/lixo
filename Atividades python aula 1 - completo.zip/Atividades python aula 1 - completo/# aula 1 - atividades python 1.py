# aula 1 - atividades python 1 - print

print('Ciências da Computação - Unicsul')
