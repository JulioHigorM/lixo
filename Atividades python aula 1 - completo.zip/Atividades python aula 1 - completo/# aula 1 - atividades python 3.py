# aula 1 - atividades python 3 - input 2

a = int(input('qual sua idade ?: '))
b = str(input('qual seu nome ?: '))

print(('seu nome é:'), (b), ('e voce tem'), (a), ('anos'))
