# aula 1 - atividades python 2 - input

a = str(input("Em qual profissão você atua ?: "))

print(("Sua profissão é:"), (a))
