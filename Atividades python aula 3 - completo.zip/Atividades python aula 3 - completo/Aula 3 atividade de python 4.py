# aula 3 atividade Python - 4 - multa

a = int(input('Digite o valor da prestação em atraso: '))
b = int(input('Digite o valor da multa de atraso: '))
c = int(input('Digite a quantidade de dias atrasado: '))

d = a + ( a * ( b / 100 / 30 ) * c ) 

print(f"o valor da prestação atualizada é: R${d:.2f}")