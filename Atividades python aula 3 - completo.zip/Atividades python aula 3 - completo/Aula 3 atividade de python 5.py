
import math

graus = float(input("Digite o valor em graus: "))

radiano = math.radians(graus)

seno = math.sin(radiano)

cosseno = math.cos(radiano)

tangente = math.tan(radiano)

print("Valor do Radiano: ", radiano)
print("Valor do Seno: ", seno)
print("Valor do Cosseno: ", cosseno)
print("Valor da Tangente: ", tangente)
