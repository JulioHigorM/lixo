# aula 3 atividade Python - 2 - minutos em horas

a = float(input('Digite o a quantidade de horas: '))

b = a * 60

print(("A quantidade de horas em minutos é:"), (b), ("minutos"))
