#aula 3 atividade de pyhton - 1

print("Volume da pirâmide")

h = float(input("Digite a Altura da pirâmide: "))
Bmenor = float(input("Digite o valor da Base menor: "))
Bmaior = float(input("Digite o valor da Base maior: "))

volume = h / 3 * (Bmaior ** 2 + Bmenor ** 2 +  (Bmaior ** 2 * Bmenor ** 2) ** 0.5)

print("A Pirâmide tem o volume do tronco em ", volume)