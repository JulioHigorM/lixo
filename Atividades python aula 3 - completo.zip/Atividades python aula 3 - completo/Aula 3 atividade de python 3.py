# aula 3 atividade Python - 3 - anos e meses em dias

a = int(input('Digite a quantidade de anos da sua idade: '))
b = int(input('Digite a quantidade de meses da sua idade: '))
c = int(input('Digite a quantidade de dias da sua idade: '))

d = a * 365
e = b * 30

f = d + e + c

print(('sua idade expressa em dias é:'), (f), ('dias'))
