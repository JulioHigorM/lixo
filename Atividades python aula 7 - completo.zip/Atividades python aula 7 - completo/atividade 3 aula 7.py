salariof = float(input("Digite  o salario fixo: "))
valorv = float(input("Digite  o valor das vendas: "))

comissao = 0.04 * valorv

salario = salariof + comissao

print(f"A comissão do funcionario é: {comissao:.2f}")
print("O salario final do funcionario é: ", salario)
