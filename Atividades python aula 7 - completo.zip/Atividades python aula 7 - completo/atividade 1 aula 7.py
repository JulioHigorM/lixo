
contador = 0
resp = "n"
print("Voce esta contando carneirinhos para dormir, continue contando ate dormir!")
while resp == "n" or resp == "N":
    
    resp = input(f"Ja foram {contador+1} carneirinhos, dormiu? (S/N) ")
    contador = contador + 1

print(f"FIM, voce dormiu. A quantidade de carneirinhos foi de: {contador}")
