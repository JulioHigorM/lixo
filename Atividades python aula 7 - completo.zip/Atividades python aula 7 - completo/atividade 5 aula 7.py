altura = float(input("Digite osua altura: "))
sexo = input("Digite seu sexo M para masculino e F para feminino: ")

if sexo == "M" or "m":
    peso = (72.7 * altura) - 58
elif sexo == "F" or "f":
    peso = (72.7 * altura) - 44.7

print(f"Se u peso ideial é: {peso:.2f} kg")
