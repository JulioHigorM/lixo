qe = 0
sn = 0

for i in range(1, 501):
    idade = int(input(f"Digite a idade do aluno:{i}: "))

    if idade >= 16:
        qe += 1

    else:
        sn += idade

if qe < 500:
    median = sn / (500 - qe)
    print(f"A media de idade dos alunos não eleitores é: {median:.2f}")

else:
    print("Não há não eleitores")

print(f"A quantidade de alunos que podem votar é: {qe}")
