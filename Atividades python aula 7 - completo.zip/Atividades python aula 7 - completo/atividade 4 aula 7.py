segundos = int(input("Digite a quantidade de segundo: "))

horas = segundos // 3600
segundos %= 3600
minutos = segundos // 60
segundos %= 60

print(f"{horas} horas, {minutos} minutos e {segundos} segundos.")
