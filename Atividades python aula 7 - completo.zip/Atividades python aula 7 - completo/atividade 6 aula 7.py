import math

areap = float(
    input("Digite o tamanho da area a ser pitnada (em metros quadrados): "))

litros = areap / 3

quantidade = math.ceil(litros / 18)

preco = quantidade * 80

print(f"Quantidade de latas de tinta necessarias: {quantidade}")
print(f"Preço total: {preco:.2f}")
