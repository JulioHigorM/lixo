# aula 2 - atividade de python 4 - calculadora baskara
import math

a = float(input('Digite o primeiro valor a: '))
b = float(input('Digite o segundo valor b: '))
c = float(input('Digite o terceiro valor c: '))

h = b * b
e = 2 * a

d = h - 4 * a * c

f = (-b + math.sqrt(d))
g = (-b - math.sqrt(d))

i = f / e
j = g / e

print(i, j)
