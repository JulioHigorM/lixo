# aula 2 - atividade de python 2 - calculo do salario + 5%

a = int(input("Digite o valor do seu salario: "))

b = 5 * (a / 100)

print(("Seu salario com um acressimo de 5% é"),
      (a + b), ('pois voce teve um acressimo de'), (b))
