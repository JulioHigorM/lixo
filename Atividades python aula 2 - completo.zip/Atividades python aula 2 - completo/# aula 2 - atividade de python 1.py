# aula 2 - atividade pyton 1 - perimetro e area

a = int(input("Digite a base do retangulo: "))
b = int(input("Digite a altura lado do retangulo: "))

c = 2 * (a + b)
d = a * b

print(str('O perimetro do retangulo é') , (c) , ('e a area é') , (d))

