# aula 2 - atividade de python 5 - Dolar para real

a = int(input('Digite o valor em Dolar que pretende converter para real: '))

b = a * 4.99

print(('O valor em reais será:'), (b))
