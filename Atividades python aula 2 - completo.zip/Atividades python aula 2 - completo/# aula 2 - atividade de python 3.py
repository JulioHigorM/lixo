# aula 2 - atividade python 3 - velocidade media com base na distancia e tempo percorrido

a = float(input('Digite a distancia entre as cidades: '))
b = float(input('Digite o tempo de duração da viagem: '))

c = a / b

print(('A velocidade media do veiculo é') , (c))


