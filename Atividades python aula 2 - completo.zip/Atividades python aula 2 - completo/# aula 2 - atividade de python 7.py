# aula 2 - atividade de python 7 - C para K e F

a = float(input('Digite a temperatura em ºC: '))

b = 1.8 * a + 32
c = a + 273

print(('A conversão de temperatura de ºC para ºF é:'), (b), ('e para ºK é:'), (c))
