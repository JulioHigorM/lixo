# aula 2 - atividade de python 6 - Restaurante

a = int(input('Digite o valor do gasto com o restaurante ComaBem: '))

b = 10 * (a / 100)
c = b + a

print(('O valor total a ser pago é'), (c),
      ('pois com a taxa do garçom há um acressimo de'), (b))
