# aula 4 - atividade de python 4 - if or else

a = int(input('Digite o valor do seu salario: '))

b = int(input('Digite o valor da sua conta de luz: '))
c = int(input('Digite o valor da sua conta de agua: '))
d = int(input('Digite o valor da sua conta de telefone: '))

e = b + c + d

if (a) < (e):
    print("Seu salario é insuficiente")
else:
    f = a - e
    print(('voce consegue pagar e restará:'), (f))