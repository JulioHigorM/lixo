# atividade 3 aula 4

print("Promoção: em comprar acima de 200 reais voce recebe 20% de desconto")
a = float(input("Digite o valor da sua compra: "))

if a > 200:
    b = a - (a * 20 / 100)
    print(f"o valor da sua compras são:{b:.2f}")
    
elif a < 200:
    print("o valor da suas compras são: ", a )
