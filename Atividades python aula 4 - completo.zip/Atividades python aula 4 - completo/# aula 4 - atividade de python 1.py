# aula 4 - atividade de python 1 - valores if or else

a = int(input("Digite um valor entre 0 e 9: "))

if a  >= 0 and a <= 9:
    print('Valor correto')
else:
    print('Valor incorreto')
