# aula 4 - atividade 2

N = 45.50
M = 37.50
n = 45.50
m = 37.50

a = input("Digite qual o seu turno de trabalho em M (matutino) ou N (Noturno): ")
b = float(input("Digite a quantidade de horas trabalhadas: "))


if a == N:
    c = n * b
    print("Seu salario diario é:", (c))
    
elif a == n:
    d = n * b
    print("Seu salario diario é:", (d))
    
elif a == M:
    e = m * b
    print("Seu salario diario é:", (e))
    
else: a == M
f = m * b
print("Seu salario diario é:", (f))