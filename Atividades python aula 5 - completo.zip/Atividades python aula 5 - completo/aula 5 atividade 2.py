
a = float(input('Digite o primeiro valor a: '))
b = float(input('Digite o segundo valor b: '))
c = float(input('Digite o terceiro valor c: '))


d = (b ** 2) - 4 * a * c


if d < 0:
    print("Não há raizes reais")

elif a == 0:
    print("Não é equação do segundo grau")

else:

    f = (-b + d ** (1 / 2)) / (2 * a)
    g = (-b - d ** (1 / 2)) / (2 * a)


    print(f"x¹ é: {f} e x² é: {g}")
