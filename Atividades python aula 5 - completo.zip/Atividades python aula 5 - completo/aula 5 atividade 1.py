

print("-------------------------------------------------------------")
print("Abaixo de 16 anos não esta elegivel a votar")
print("Entre 18 e 65 anos o voto é obrigatorio")
print("Entre 16 e 18 anos e maior de 65 anos seu voto é facultativo")
print("-------------------------------------------------------------")
print("Para tirar seu titulo de eletor é necessario:")
b = str(input("Escreva seu nome: "))
a = int(input("Digite o valor da sua idade: "))





if a < 16:
    print("o-----------------------------------------------------------o")
    print("|          Voce não esta elegivel para votar               |")
    print("o-----------------------------------------------------------o")
    
elif a >= 18 and a <= 65 : 
    print("o-----------------------------------------------------------o")
    print("|  Voce esta elegivel para votar e seu voto é obrigatorio   |")
    print("o-----------------------------------------------------------o")

elif a >= 16 and a <= 65:
    print("o-----------------------------------------------------------o")
    print("|                  Seu voto é facutativo                    |")
    print("o-----------------------------------------------------------o")
        
else: 
    print("o-----------------------------------------------------------o")
    print("|                 Seu voto é facultativo                    |")  
    print("o-----------------------------------------------------------o")    
    

    