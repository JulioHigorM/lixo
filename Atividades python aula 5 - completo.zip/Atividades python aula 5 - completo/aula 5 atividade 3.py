
a = str(input("Digite o nome do produto: "))
b = float(input("Digite o valor do produto: "))

if b < 10:
    c1 = b * 70 / 100
    c2 = b + c1
    print(f"O produto: {a} rendeu o valor de venda de {
          c2} pois houve um acressimo de 70% sendo: {c1}")

elif b >= 10 and b < 30:
    d1 = b * 50 / 100
    d2 = b + d1
    print(f"O produto: {a} rendeu o valor de venda de {
          d2} pois houve um acressimo de 50% sendo: {d1}")

elif b >= 30 and b < 50:
    e1 = b * 40 / 100
    e2 = b + e1
    print(f"O produto: {a} rendeu o valor de venda de {
          e2} pois houve um acressimo de 40% sendo: {e1}")

elif b >= 50:
    f1 = b * 30 / 100
    f2 = b + f1
    print(f"O produto: {a} rendeu o valor de venda de {
          f2} pois houve um acressimo de 30% sendo: {f1}")
