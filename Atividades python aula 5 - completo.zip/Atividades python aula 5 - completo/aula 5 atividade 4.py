
print("----------------------")
print("| calculadora basica |")
print("----------------------")

a = float(input("Digite o primeiro valor: "))
c = input("Digite a operação esperada: ( +   -    X    / ): ")
b = float(input("Digite o segundo valor: "))

if c == "+":
    d = a + b
    print("----------------")
    print(f"Resultado: {d}")
    print("----------------")

elif c == "-":
    d1 = a - b
    print("----------------")
    print(f"Resultado: {d1}")
    print("----------------")

elif c == "x" or "X":
    d2 = a * b
    print("----------------")
    print(f"Resultado: {d2}")
    print("----------------")

elif c == "/":
    d3 = a / b
    print("----------------")
    print(f"Resultado: {d3}")
    print("----------------")
